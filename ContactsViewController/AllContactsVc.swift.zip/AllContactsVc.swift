//
//  AllContactsVc.swift
//  ContactsLite
//
//  Created by devi-pt6261 on 28/03/23.
//

import UIKit

struct SectionContent{
    let sectionName : String
    var rows: [String]
}

var dataSource:[SectionContent] = [
//    SectionContent(sectionName: "A", rows: ["Abi","Arshad","Akshaya"]),
//    SectionContent(sectionName: "D", rows: ["Devi","Deepika"]),
//    SectionContent(sectionName: "J", rows: ["Jitiendran"]),
//    SectionContent(sectionName: "N", rows: ["Noel","Nishi"]),
//    SectionContent(sectionName: "S", rows: ["Sathya Narayanan", "Sankaranarayanan"]),
//    SectionContent(sectionName: "V", rows: ["Venu Gopal"]),
//    SectionContent(sectionName: "Z", rows: ["Zion"])
]

class AllContactsVc: UITableViewController,UISearchControllerDelegate,UISearchBarDelegate,UISearchResultsUpdating{
     
    static var shared:AllContactsVc = AllContactsVc()
    
    var filteredData:[SectionContent]=[]
    
    lazy var nameLabel : UILabel = {
        let label = UILabel()
        label.text = "Devi Sankar"
        label.textColor = .label
        label.font = .systemFont(ofSize: 25, weight: .bold)
        return label
    }()
    lazy var mailLabel : UILabel = {
        let label = UILabel()
        label.text = "devi@mail.com"
        label.textColor = .secondaryLabel
        return label
    }()
    lazy var imageView :UIImageView = {
        let imageView = UIImageView()
        imageView.image =  UIImage(systemName: "person.circle.fill")
        imageView.tintColor = .systemGray
        return imageView
    }()
    lazy var profileCardLabel:UIView = {
        let view = UIView(frame:CGRect(x: 0, y: 0, width: view.frame.size.width, height: 100))
        view.backgroundColor = .secondarySystemFill
        view.layer.cornerRadius = 10
        return view
    }()
    lazy var searchController:UISearchController = {
        let searchBar = UISearchController()
        searchBar.delegate = self
        searchBar.searchBar.delegate = self
        return searchBar
    }()
    
    lazy var searchImage:UIImageView = {
        let images = UIImageView()
        images.image = UIImage(systemName: "magnifyingglass")
        images.tintColor = .systemGray
        return images
    }()
    
    lazy var searchTextLabel : UILabel = {
        let label = UILabel()
        label.text = "NO SEARCH RESULTS FOUND !"
        label.textColor = .systemBlue
        return label
    }()
    
    lazy var searchResultView:UIView = {
        let view = UIView()
        view.layer.cornerRadius = 10
        view.isHidden = true
        return view
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .systemBackground
        
        setUpNavigationItems()
        
        searchController.searchResultsUpdater = self
        
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        
        addSubviewsToProfileCardLabel()
        
        addSubViewsToSearchResultsView()
        
        setUpConstraints()
        
        tableView.tableHeaderView = profileCardLabel
        tableView.keyboardDismissMode = .onDrag
        tableView.backgroundView = searchResultView
        
        
    }



        
    
    
    func setUpNavigationItems() {
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(image: UIImage(systemName: "plus"),style: .plain, target: self, action: #selector(addButton))
        
        title = "iPhone"
        
        navigationController?.navigationBar.prefersLargeTitles = true
        
        navigationItem.searchController = searchController
        
        navigationItem.hidesSearchBarWhenScrolling = false
        
    }
   
    
    func addSubviewsToProfileCardLabel(){
        
        profileCardLabel.addSubview(imageView)
        profileCardLabel.addSubview(nameLabel)
        profileCardLabel.addSubview(mailLabel)
    }
    
    func addSubViewsToSearchResultsView(){
        searchResultView.addSubview(searchImage)
        searchResultView.addSubview(searchTextLabel)
    }
    
    func setUpConstraints(){
        
        imageView.translatesAutoresizingMaskIntoConstraints = false
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        mailLabel.translatesAutoresizingMaskIntoConstraints = false
        
        searchImage.translatesAutoresizingMaskIntoConstraints = false
        searchTextLabel.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            
            
            imageView.topAnchor.constraint(equalTo: profileCardLabel.topAnchor, constant: 10),
            imageView.leadingAnchor.constraint(equalTo: profileCardLabel.leadingAnchor, constant: 10),
            imageView.widthAnchor.constraint(equalToConstant: 80),
            imageView.heightAnchor.constraint(equalToConstant: 80),
            
            nameLabel.topAnchor.constraint(equalTo: profileCardLabel.topAnchor, constant: 20),
            nameLabel.leadingAnchor.constraint(equalTo: imageView.trailingAnchor, constant: 20),
            nameLabel.trailingAnchor.constraint(equalTo: profileCardLabel.trailingAnchor, constant: -10),
            nameLabel.heightAnchor.constraint(equalToConstant: 30),
            
            mailLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 10),
            mailLabel.leadingAnchor.constraint(equalTo: imageView.trailingAnchor, constant: 22),
            mailLabel.trailingAnchor.constraint(equalTo: profileCardLabel.trailingAnchor, constant: -10),
            mailLabel.heightAnchor.constraint(equalToConstant: 30),
            
           
            searchImage.centerYAnchor.constraint(equalTo: searchResultView.centerYAnchor),
            searchImage.leadingAnchor.constraint(equalTo: searchResultView.leadingAnchor, constant: 10),
            searchImage.widthAnchor.constraint(equalToConstant: 80),
            searchImage.heightAnchor.constraint(equalToConstant: 80),
            
            searchTextLabel.centerYAnchor.constraint(equalTo: searchResultView.centerYAnchor),
            searchTextLabel.leadingAnchor.constraint(equalTo: searchImage.trailingAnchor, constant: 20),
            searchTextLabel.widthAnchor.constraint(equalTo:searchResultView.widthAnchor),
            searchTextLabel.heightAnchor.constraint(equalTo: searchResultView.heightAnchor)
            
            
            
        ])
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        print(filteredData.isEmpty ? (dataSource.count) :filteredData.count)
        return filteredData.isEmpty ? (dataSource.count) :filteredData.count
    }
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if filteredData.isEmpty {
            return 5
//            return  dataSource[section].rows.count
        }
        else{
            return  filteredData[section].rows.count
        }
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        print(indexPath)
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell",for: indexPath)
        if filteredData.isEmpty{
            cell.textLabel?.text = dataSource[indexPath.section].rows[indexPath.row]
        }
        else{
            cell.textLabel?.text = filteredData[indexPath.section].rows[indexPath.row]
        }
        
        return cell
    }
    
    override func sectionIndexTitles(for tableView: UITableView) -> [String]? {
        return ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
    }
    override func tableView(_ tableView: UITableView, sectionForSectionIndexTitle title: String, at index: Int) -> Int {
        return index
    }
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        if filteredData.isEmpty{
            return dataSource[section].sectionName
        }
        else{
            return filteredData[section].sectionName
        }
    }
    
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("\(dataSource[indexPath.section].rows[indexPath.row]) is Selected")
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    @objc func addButton(){
        present(UINavigationController(rootViewController:  InfoSheetViewController()), animated: true)
        print("add ")
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        //        profileCardLabel.isHidden = true
        //        profileCardLabel.frame.size.height = 0
        tableView.tableHeaderView = nil
        print("did begin")
    }
   
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        //        profileCardLabel.isHidden = false
        //        profileCardLabel.frame.size.height = 100
        print("cancel button")
        tableView.tableHeaderView = profileCardLabel
        filteredData.removeAll()
        tableView.reloadData()
        
    }
    
    func updateSearchResults(for searchController: UISearchController) {
        print("update search results")
        guard let text = searchController.searchBar.text else{
            return
        }
        if !text.isEmpty {
            filterInput(input: text)
        }
        else{
            filteredData.removeAll()
            searchResultView.isHidden = true
//            tableView.tableHeaderView = nil
            tableView.reloadData()
        }
        
        
    }
    
    func filterInput(input:String){
        
        var tempArr:[String] = []
        if input.isEmpty {
            filteredData = dataSource
        }
        else{
            filteredData.removeAll()
            
            for i in 0..<dataSource.count{
                var name:String = ""
                var rows:[String] = []
                for string in dataSource[i].rows{
                    if string.lowercased().contains(input.lowercased()){
                        name = String(describing:string.first!)
//                        for j in input.uppercased(){
//                            print(j)
//                            var index:Int = 0
//                            if let k = string.firstIndex(of: j) {
//                                index = k.utf16Offset(in:string)
//
//                            }
//                                else{
//                                print("not found")
//                            }
//
//                            print("\(string) index is \(index)")
//                            let attributedString = NSMutableAttributedString(string: string)
//                            attributedString.addAttribute(.font, value: UIFont.systemFont(ofSize: 30, weight: .bold), range: NSRange(location: index, length: string.count-index))
                            
                            if !tempArr.contains(string){
                                tempArr.append(string)
                                rows.append(string)
                            }
                        }
                        
                    }
                    filteredData.append(SectionContent(sectionName: name, rows: rows))
                    
                }
                
            }
            
            if tempArr.isEmpty {
                
                searchResultView.isHidden = false
                
            }
            else {
                searchResultView.isHidden = true
            }
            tableView.reloadData()
        
            
        }
    func addToDataSource(string:String){
        let startingLetter:String = String(string.first!)
        if(dataSource.isEmpty){
            dataSource.append(SectionContent(sectionName: startingLetter, rows: [string]))
        }
        else{
            
            for i in 0..<dataSource.count {
                if dataSource[i].sectionName == startingLetter {
                    dataSource[i].rows.append(string)
                }
                else{
                    dataSource.append(SectionContent(sectionName: startingLetter, rows: [string]))
                }
            }
        }
        print("in ds \(dataSource)")
        tableView.reloadData()
    }
        
    
}
